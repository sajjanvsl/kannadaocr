# OCR functions and image enhancement utilities
