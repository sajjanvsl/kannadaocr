# How to contribute to Kannada OCR project
