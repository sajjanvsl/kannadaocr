# Old Kannada ➡️ New Kannada converter functions
