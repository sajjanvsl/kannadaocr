# CNN model building and training functions
