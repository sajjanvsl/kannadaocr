# Kannada OCR Streamlit app main entry point
