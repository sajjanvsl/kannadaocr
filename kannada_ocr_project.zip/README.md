# Kannada OCR App - README content with badges and guide
